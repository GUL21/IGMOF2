<?php
	session_start();
if ($_SESSION['auth_admin'] == "yes_auth")
{
  define('myeshop', true);
       
       if (isset($_GET["logout"]))
    {
        unset($_SESSION['auth_admin']);
        header("Location: ../login.php");
    }
  $_SESSION['urlpage'] = "<a href='index.php' >Главная</a>";

	include("include/db_connect.php");

	$id=$_GET["proj_id"];

	if (isset($_POST['save']))
	{
		$authors = implode('<br><br>',$_POST['authors']);
		$other = $_POST['other'];
		$zag = $_POST['zag'];
		$anotation = $_POST['anotation'];
		$main = $_POST['main'];
		$slova = implode(', ',$_POST['slova']);
		$leader = $_POST['leader'];
		$rk = $_POST['rk'];
		$date = $_POST['date'];

		$result = mysql_query("UPDATE projects SET authors='$authors', other='$other', title='$zag', anotation='$anotation', main='$main', keywords='$slova', leader='$leader', rk='$rk', data='$date' WHERE proj_id='$id'");
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Редагування проекта</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">
	<script src="js/jquery-1.7.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
	<script type="text/javascript" src="js/ckeditor/ckeditor.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
</head>
<body>
	<div id="block-body">
	<header id="head">
		<div id="block-header">
			<?php
				include("include/block-header.php");
			?>
		</div>
	</header>
	<div id="block-left">
		<?php
			include("include/block-left.php");
		?>
	</div>
	<div id="block-right">
		<?php
			include("include/block-right.php");
		?>
	</div>
	<div id="block-content">
		<h1>Редагування проекта</h1>
		<?php
		$result = mysql_query("SELECT * FROM projects WHERE proj_id='$id'",$link);  
	 				if (mysql_num_rows($result) > 0)
					{
 						$row = mysql_fetch_array($result); 
 
 					do
 					{
 						echo 
 						'
 						<form method="post" action="view.php?proj_id='.$row["proj_id"].'" id="forma">
 						<br>
 						<p class="green">Заголовок</p>
 						<input type="text" name="zag" value="'.$row["title"].'" class="auto"><br><br>
 						<p class="green">Анотація</p>
						<textarea name="anotation">'.$row["anotation"].'</textarea><br><br>
 						<p class="green">Текст</p>
						<textarea name="main">'.$row["main"].'</textarea><br><br>
 						<p class="green">Автори</p>
 						<input type="text" class="auto" name="authors" value="'.$row["authors"].'">
						<br><br>
 						';
 						?>
 						<select name="authors[]" size="10" multiple>
 							<?php
 							$result1 = mysql_query("SELECT * FROM employees ORDER BY PIB ASC",$link);  
	 				if (mysql_num_rows($result1) > 0)
					{
 						$row1 = mysql_fetch_array($result1); 
 
 					do
 					{
 							echo 
 							'
								<option>'.$row1["PIB"].'</option>
 							';
 								}
    				while ($row1 = mysql_fetch_array($result1));
				} 
 							?>
 							<?php
 							echo 
 							'
 						</select>
 						<p class="green">Інші</p>
 						<textarea name="other">'.$row["other"].'</textarea><br><br>
 						<p class="green">Ключові слова</p>	
 						<input type="text" class="auto" name="slova" value="'.$row["keywords"].'">
						<br><br>
 						';
 						?>
 						<select name="slova[]" size="10" multiple>
 							<?php
 							$result1 = mysql_query("SELECT * FROM keywords ORDER BY keyword ASC",$link);  
	 				if (mysql_num_rows($result1) > 0)
					{
 						$row1 = mysql_fetch_array($result1); 
 
 					do
 					{
 							echo 
 							'
								<option>'.$row1["keyword"].'</option>
 							';
 								}
    				while ($row1 = mysql_fetch_array($result1));
				} 
 							?>
 							<?php
 							echo 
 							'
 						</select>
 						<p class="green">Керівник</p>	
 						<input type="text" class="auto" name="leader" value="'.$row["leader"].'">
						<br><br>
 						';
 						?>
 						<select name="leader" size="10">
 							<?php
 							$result1 = mysql_query("SELECT * FROM employees ORDER BY PIB ASC",$link);  
	 				if (mysql_num_rows($result1) > 0)
					{
 						$row1 = mysql_fetch_array($result1); 
 
 					do
 					{
 							echo 
 							'
								<option>'.$row1["PIB"].'</option>
 							';
 								}
    				while ($row1 = mysql_fetch_array($result1));
				} 
 							?>
 							<?php
 							echo 
 							'
 						</select>
 						<br><br>
 						<p class="green">РК</p>	
 						<input type="text" name="rk" value="'.$row["rk"].'"><br><br>
 						<p class="green">Роки виконання</p>	
 						<input type="text" name="date" value="'.$row["data"].'"><br><br>
 						<input type="submit" name="save" value="Зберегти">
 						</form>
 						';
 					}
    				while ($row = mysql_fetch_array($result));
				} 
				?>
	</div>
	<footer id="foot">
	</footer>
	<script type="text/javascript">
		CKEDITOR.replace("main");
		CKEDITOR.replace("anotation");
		CKEDITOR.replace("other");
	</script>
	</div>
</body>
</html>
<?php
}else
{
    header("Location: ../login.php");
}
?>