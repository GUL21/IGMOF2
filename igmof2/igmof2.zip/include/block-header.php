<a href="index.php">
	<img src="img/logo.png" id="logo">
</a>
<h1>Інститут геохімії, мінералогії та рудоутворення ім. М.П. Семененка НАН України</h1>
<form method="get" action="search.php?q=">
	<input type="text" name="q" value="<?php echo $search; ?>">
	<input type="submit" name="submit" value="Пошук">
</form>